
public class KPair {
	public byte[] publicKey;
	public byte[] privateKey;

	public KPair(byte[] publicKey, byte[] privateKey) {
		this.publicKey = publicKey;
		this.privateKey = privateKey;
	}
}
