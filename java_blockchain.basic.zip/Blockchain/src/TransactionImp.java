
public class TransactionImp implements Transaction {
	
	private byte[] own_sender;
	private byte[] own_receiver;
	private int own_amount;
	private byte[] own_signature;
	
	public TransactionImp() {
		own_sender=null;
		own_receiver=null;
		own_amount=0;
		own_signature=null;
	}

	@Override
	public void sign(byte[] pvk) {
		own_signature=Utils.sign(Utils.toBytes(own_amount), pvk);
	}

	@Override
	public boolean isSignatureValid() {
		return false;
	}

	@Override
	public byte[] toBytes() {
		return null;
	}

	@Override
	public void setSender(byte[] sender) {
		own_sender=sender;
	}

	@Override
	public void setReceiver(byte[] receiver) {
		own_receiver=receiver;
	}

	@Override
	public void setAmount(int amount) {
		own_amount=amount;
	}

	@Override
	public void setSignature(byte[] signature) {
		own_signature=signature;
	}

	@Override
	public byte[] getSender() {
		return own_sender;
	}

	@Override
	public byte[] getReceiver() {
		return own_receiver;
	}

	@Override
	public int getAmount() {
		return own_amount;
	}

	@Override
	public byte[] getSignature() {
		return own_signature;
	}

}
