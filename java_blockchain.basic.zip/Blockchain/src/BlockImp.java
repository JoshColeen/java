
public class BlockImp implements Block {

	private byte[] own_miner;
	private byte[] own_hash;
	private byte[] own_prevHash;
	private int own_nonce;
	private Transaction own_transaction;
	
	public BlockImp(){
		own_miner=null;
		own_hash=null;
		own_prevHash=null;
		own_nonce=0;
		own_transaction =new TransactionImp();
	}

	@Override
	public void setMiner(byte[] miner) {
		own_miner=miner;
	}

	@Override
	public void setNonce(int nonce) {
		own_nonce=nonce;
	}

	@Override
	public void setTransaction(Transaction transaction) {
		own_transaction=transaction;
	}

	@Override
	public void setPrevHash(byte[] prevHash) {
		own_prevHash=prevHash;
	}

	@Override
	public void setHash(byte[] hash) {
		own_hash=hash;
	}

	@Override
	public byte[] getMiner() {
		return own_miner;
	}

	@Override
	public int getNonce() {
		return own_nonce;
	}

	@Override
	public byte[] getHash() {
		return own_hash;
	}

	@Override
	public byte[] getPrevHash() {
		return own_prevHash;
	}

	@Override
	public Transaction getTransaction() {
		return own_transaction;
	}

	@Override
	public void compHash() {
		own_hash=Utils.getHash(toBytes());
	}

	@Override
	public boolean isHashValid() {
		return Utils.validBlockHash(own_hash);
	}

	@Override
	public void mine() {
		while(!Utils.validBlockHash(own_hash)) {
			own_hash[0]+=own_nonce;
			own_nonce++;
		}
	}

	@Override
	public byte[] toBytes() {
		byte[] buf=own_transaction.getSender();
		buf=Utils.concat(buf,own_transaction.getReceiver());
		buf=Utils.concat(buf,Utils.toBytes(own_transaction.getAmount()));
		buf=Utils.concat(buf,own_transaction.getSignature());
		return buf;
	}

}
