public class BlockchainImp implements Blockchain {
	
	List<Block> own_blocks;
	
	public BlockchainImp() {
		own_blocks=null;
	}

	@Override
	public int length() {
		int i=0;
		own_blocks.findFirst();
		while(!own_blocks.last()) {
			own_blocks.findNext();
			i++;
		}
		return i;
	}

	@Override
	public List<Block> getBlocks() {
		return own_blocks;
	}

	@Override
	public int getBalance(byte[] pbk) {
		own_blocks.findFirst();
		while(!own_blocks.last()) {
			Block buf=own_blocks.retrieve();
			if(buf.getTransaction().getReceiver()==pbk) {
				int ret;
				ret=buf.getTransaction().getAmount();
				if(ret<0) return -1;
				else return ret;
			}
			own_blocks.findNext();
		}
		return 0;
	}

	@Override
	public void removeInvalid() {
		own_blocks.findFirst();
		while(!own_blocks.last()) {
			Block buf=own_blocks.retrieve();
			if(!buf.isHashValid()
				||!buf.getTransaction().isSignatureValid()
				||!(buf.getTransaction().getAmount()<=0)) 
			{
				own_blocks.remove();
				continue;
			}
			own_blocks.findNext();
		}
	}

	@Override
	public boolean addBlock(Block b) {
		if(own_blocks==null) {
			b.setPrevHash(null);
		}
		else {
			own_blocks.findFirst();
			while(!own_blocks.last()) {
				own_blocks.findNext();
			}
			Block buf=own_blocks.retrieve();
			b.setPrevHash(buf.getHash());
		}
		own_blocks.insert(b);
		return true;
	}

	@Override
	public byte[] getLastBlockHash() {
		own_blocks.findFirst();
		while(!own_blocks.last()) {
			own_blocks.findNext();
		}
		Block buf=own_blocks.retrieve();
		return buf.getHash();
	}
}
