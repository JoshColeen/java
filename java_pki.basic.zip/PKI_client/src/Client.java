import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.io.File;
import java.io.FileOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.security.spec.X509EncodedKeySpec;
import java.sql.Date;

public class Client {
	private static Socket clientSocket = null; // The client socket
	private static PrintWriter os = null; // The output stream
	private static BufferedReader is = null; // The input stream
	private static BufferedReader inputLine = null;
	
	public static void writeToFile(String path, byte[] key) throws IOException {
		File f = new File(path);
		f.getParentFile().mkdirs();
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(key);
		fos.flush();
		fos.close();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public static void main(String[] args) throws InterruptedException, NoSuchAlgorithmException, InvalidKeySpecException, ClassNotFoundException, InvalidKeyException, SignatureException {
		System.out.println("Client started!");
		int portNumber = 3334;
		String host = "localhost";
		// Open a socket on a given host and port. Open input and output streams.
		try {
			clientSocket = new Socket(host, portNumber);
			inputLine = new BufferedReader(new InputStreamReader(System.in));
			is = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			os = new PrintWriter(clientSocket.getOutputStream(), true); 		
		} catch (UnknownHostException e) {
			System.err.println("Don't know about host " + host);
		} catch (IOException e) {
			System.err.println("Couldn't get I/O for the connection to the host " + host);
		}

		/*
		 * If everything has been initialized then we want to write some data to
		 * the socket we have opened a connection to on the port portNumber.
		 */
		if (clientSocket != null && os != null && is != null) {
			try {		
				while (true) {
					
					PrivateKey privateKey=null;
					PublicKey publicKey=null;
					byte[] password;
					
					String str = inputLine.readLine().trim();
					os.println(str);
					if (str.equals("end") || str.equals("quit") )
						break;
					else if(str.equals("signature")) {
	///////////////////////////// Digital signature   //////////////////////////////////////
						System.out.println("Signaturing...");
						
						String data = new String("This is SE375 SYSTEM PROGRAMMING.");
						
						//The list consists of the message and the signature.
						List<byte[]> list =new ArrayList<byte[]>();
						
						try { 
							Signature rsa = Signature.getInstance("SHA1withRSA"); 
						
							list.add(data.getBytes());
						
							//retrieve the Private Key from a file
							byte[] keyBytes = Files.readAllBytes(new File("KeyStore/privateKey").toPath());
							PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
							KeyFactory kf = KeyFactory.getInstance("RSA");
							PrivateKey priKey =  kf.generatePrivate(spec);

							//Sign the data using the private key 
							rsa.initSign(priKey);
							rsa.update(data.getBytes());
						
							byte[] signature = rsa.sign();
							list.add(signature);
						
							// write the (message, signature) to a file
							File f = new File("SignStore/SignedData.txt");
							f.getParentFile().mkdirs();
							ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("SignStore/SignedData.txt"));
							out.writeObject(list);
							out.close();
							System.out.println("Your file is ready.");
						} catch ( InvalidKeyException | NoSuchAlgorithmException | 
								  InvalidKeySpecException | SignatureException | IOException e) {
							System.err.println(e.getMessage());
						}
						
						System.out.println("Signature done!");
	////////////////////////////////////////////////////////////////////////////////////////
					}
					else if(str.equals("verify")) {
						System.out.println("Verifying...");
						//////////////////////////////    Verify   /////////////////////////
						List<byte[]> lt;

						// retrieves the byte arrays that contains the message and signature form the file.
						ObjectInputStream in = new ObjectInputStream(new FileInputStream("SignStore/SignedData.txt"));
					    lt = (List<byte[]>) in.readObject();
					    in.close();
					    byte [] msg = lt.get(0);
					    byte [] signature = lt.get(1);
					    
					    // retrieve the Public Key from a file.
						byte[] keyBytes = Files.readAllBytes(new File("KeyStore/publicKey").toPath());
						X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
						KeyFactory kf = KeyFactory.getInstance("RSA");
						PublicKey pubKey = kf.generatePublic(spec);
					    
						// Initialize the signature with the Public Key, 
						// Updates the data to be verified and then verifies them using the signature
					    Signature sig = Signature.getInstance("SHA1withRSA");
						sig.initVerify(pubKey);
						sig.update(msg);
						
						Boolean verified = sig.verify(signature);
					   
					    System.out.println(verified ? "VERIFIED MESSAGE" + 
					      "\n----------------\n" + new String(msg) : "Could not verify the signature.");
					    System.out.println("Verify done!");
					}
	////////////////////////////////////////////////////////////////////////////////////////
					str=is.readLine().trim();
					System.out.println(str);
					if(str.equalsIgnoreCase("start_accepted")) {
						try {//generate the public/private key pair.
							KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
							keyGen.initialize(1024);
							
							KeyPair pair = keyGen.generateKeyPair();
							privateKey = pair.getPrivate();
							publicKey = pair.getPublic();
							
							//System.out.println(publicKey.getFormat());
							//System.out.println(privateKey.getFormat());
							
							writeToFile("KeyStore/publicKey", publicKey.getEncoded());
							//change path to usb
							writeToFile("KeyStore/privateKey",privateKey .getEncoded());
							System.out.println("Key pair generated!");
///////////////////////    Use Message digest to create a hash of the message      ///////////////
							password=new String("test").getBytes();//////// password
							MessageDigest md=MessageDigest.getInstance("SHA-1");
							byte[] hashInBytes=md.digest(password);
							//bytex to hex
							StringBuilder sb=new StringBuilder();
							for(byte b:hashInBytes) {
								sb.append(String.format("%02x",b));
							}
							System.out.println("Password in bytes - "+hashInBytes.length+" : "+sb.toString());
							
							String name="Yigit";////////////////////////user name
							String email="Yigit@aaa.bbb.com";
							String dt= "5/5/2019";
				
							byte[] data1 = name.getBytes();
							byte[] data2 = email.getBytes();
							byte[] data3 = dt.getBytes();
							byte[] data4 = publicKey.getEncoded();


							// MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
						    MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
						    messageDigest.update(data1);
						    messageDigest.update(data2);
						    messageDigest.update(data3);
						    messageDigest.update(data4);
					        hashInBytes = messageDigest.digest();
				        
						    sb = new StringBuilder();
						    for (byte b : hashInBytes) {
						        sb.append(String.format("%02x", b));
						    }
		//////////////////////////////// finally client send a string to server ///////////////////////////
						    String msg=sb.toString();
							os.println(msg);//string transfered to server
							os.flush();
							System.out.println(String.format("Msg : %s",msg));
							System.out.println(String.format("Public key sent! Size : %d",msg.length()));
						} catch (NoSuchAlgorithmException e) {
							System.err.println(e.getMessage());
						} catch (IOException e) {
							System.err.println(e.getMessage());
						}
					} 
				}
				// Close the output stream, close the input stream, close the socket
				os.close();
				is.close();
				clientSocket.close();
			} catch (IOException e) {
				System.err.println("IOException:  " + e);
			}
		}
	}
}