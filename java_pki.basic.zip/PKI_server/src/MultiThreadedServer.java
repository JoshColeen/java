import java.net.*;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.List;
import java.io.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;

public class MultiThreadedServer {
	private static boolean closed = false;
	
	public static void writeToFile(String path, byte[] key) throws IOException {
		File f = new File(path);
		f.getParentFile().mkdirs();
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(key);
		fos.flush();
		fos.close();
	}
	
	public static void main(String[] args) throws Exception {
		System.out.println("Multi thread server started!");
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(3334);
		} catch (IOException ioe) {
			System.out.println("Could not create server socket on port 3334. Quitting.");
			System.exit(-1);
		}

		while (!closed) {
			Socket s = ss.accept();
			Thread clientThread = new Thread (new MultiThreadedServer().new ClientServiceThread(s));
			clientThread.start();
		}
		ss.close();
		System.out.println("Server Stopped");
	}

	public class ClientServiceThread implements Runnable {
		public static final int none_state = 10;
		public static final int start_accepted = 20;
		Socket s;
		boolean clientStop = false;
		ClientServiceThread(Socket s) {
			this.s = s;
		}
		public void run() {
			int state=none_state;
			System.out.println("Client Service thread run()!");
			BufferedReader din = null;
			PrintWriter dout = null;
			System.out.println("Accepted Client Address - " + s.getInetAddress().getHostName());
			try {
				din = new BufferedReader(new InputStreamReader(s.getInputStream()));
				dout = new PrintWriter(s.getOutputStream(), true);

				while (! clientStop) {
					String clientCommand = din.readLine();
					if(state==start_accepted) {
						System.out.println("pubKey received : "+clientCommand);
						String data=clientCommand;
///////////////////////////////////////////////////////////////////////////////////////////////////////////
						try {

							KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
							keyGen.initialize(1024);
							
							KeyPair pair = keyGen.generateKeyPair();
							PrivateKey privateKey = pair.getPrivate();
							PublicKey publicKey = pair.getPublic();
							
							// System.out.println(publicKey.getFormat());
							// System.out.println(privateKey.getFormat());
							
							writeToFile("ServerKeyStore/publicKey", publicKey.getEncoded());
							writeToFile("ServerKeyStore/privateKey",privateKey .getEncoded());
							System.out.println("server key pair generated!");
					////////////////////////////////////////////////////////////////////////////////////
							List<byte[]> list =new ArrayList<byte[]>();
							Signature rsa = Signature.getInstance("SHA1withRSA"); 
							
							list.add(data.getBytes());
						
							//retrieve the Private Key from a file
							byte[] keyBytes = Files.readAllBytes(new File("ServerKeyStore/privateKey").toPath());
							PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
							KeyFactory kf = KeyFactory.getInstance("RSA");
							privateKey =  kf.generatePrivate(spec);

							//Sign the data using the private key 
							rsa.initSign(privateKey);
							rsa.update(data.getBytes());
						
							byte[] signature = rsa.sign();
							list.add(signature);
						
							// write the (message, signature) to a file
							File f = new File("SignStore/SignedData.txt");
							f.getParentFile().mkdirs();
							ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("SignStore/SignedData.txt"));
							out.writeObject(list);
							out.close();
							System.out.println("Your certification is stored in file system.");
						} catch (NoSuchAlgorithmException e) {
							System.err.println(e.getMessage());
						} catch (IOException e) {
							System.err.println(e.getMessage());
						} catch ( InvalidKeyException | InvalidKeySpecException | SignatureException e) {
							System.err.println(e.getMessage());
						}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
						writeToFile("Repository/pubkeyInfo", clientCommand.getBytes());
						System.out.println("pubKey stored!");
						state=none_state;
					}
					else if(state==none_state) {
						System.out.println("Client Says :" + clientCommand);
						if (clientCommand.equalsIgnoreCase("quit")) {
							clientStop = true;
							System.out.print("Stopping client thread for client : ");
						} else if (clientCommand.equalsIgnoreCase("end")) {
							clientStop = true;
							System.out.print("Stopping client thread for client : ");
							closed = true;
						} else if (clientCommand.equalsIgnoreCase("request_start")) {// client request received
							dout.println("start_accepted");// allow to generate the public/private key pair.
							dout.flush();
							state=start_accepted;
						} 
						else {
							dout.println("Server Says :??? " + clientCommand);
							dout.flush();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					din.close();
					dout.close();
					s.close();
					System.out.println("...Stopped");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
}